@echo off
echo ==================================
echo 🧬 BioSemantica - Quick Launch
echo ==================================
echo.

REM Check if virtual environment exists
if not exist "venv\" (
    echo 📦 Creating virtual environment...
    python -m venv venv
    echo ✅ Virtual environment created
) else (
    echo ✅ Virtual environment found
)

echo.
echo 🔌 Activating virtual environment...
call venv\Scripts\activate.bat

echo.
echo 📥 Installing dependencies...
pip install -q -r requirements_hybrid.txt

echo.
echo 🔍 Checking database status...
python -c "from biology_hybrid_search import BiologyHybridSearch; import sys; search = BiologyHybridSearch('https://6638cf80-266b-4b74-b8cc-aac14899c528.us-east4-0.gcp.cloud.qdrant.io', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJhY2Nlc3MiOiJtIn0.xA63-tAtaxTSPSPtHU5DywVjpqrn-WhLK-Dn68PN35U'); collections = search.client.get_collections(); exists = any(c.name == 'biology_hybrid_search' for c in collections.collections); info = search.client.get_collection('biology_hybrid_search') if exists else None; print(f'✅ Database ready with {info.points_count} documents' if exists and info else '⚠️  Database not found')"

if errorlevel 1 (
    echo.
    set /p INIT="Initialize database now? (y/N): "
    if /i "%INIT%"=="y" (
        echo 🚀 Initializing database...
        python initialize_hybrid_db.py
    )
)

echo.
echo ==================================
echo 🚀 Starting BioSemantica Server
echo ==================================
echo.
echo Backend: http://localhost:8000
echo Frontend: Open index.html in browser
echo.
echo Press Ctrl+C to stop
echo.

python app_final.py
