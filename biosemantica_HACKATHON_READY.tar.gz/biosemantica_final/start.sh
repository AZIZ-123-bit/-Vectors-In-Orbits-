#!/bin/bash

echo "=================================="
echo "🧬 BioSemantica - Quick Launch"
echo "=================================="
echo ""

# Check if virtual environment exists
if [ ! -d "venv" ]; then
    echo "📦 Creating virtual environment..."
    python3 -m venv venv
    echo "✅ Virtual environment created"
else
    echo "✅ Virtual environment found"
fi

echo ""
echo "🔌 Activating virtual environment..."
source venv/bin/activate

echo ""
echo "📥 Installing dependencies..."
pip install -q -r requirements_hybrid.txt

echo ""
echo "🔍 Checking database status..."
python3 -c "
from biology_hybrid_search import BiologyHybridSearch
import sys
try:
    search = BiologyHybridSearch(
        'https://6638cf80-266b-4b74-b8cc-aac14899c528.us-east4-0.gcp.cloud.qdrant.io',
        'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJhY2Nlc3MiOiJtIn0.xA63-tAtaxTSPSPtHU5DywVjpqrn-WhLK-Dn68PN35U'
    )
    collections = search.client.get_collections()
    exists = any(c.name == 'biology_hybrid_search' for c in collections.collections)
    if exists:
        info = search.client.get_collection('biology_hybrid_search')
        print(f'✅ Database ready with {info.points_count} documents')
        sys.exit(0)
    else:
        print('⚠️  Database not found')
        sys.exit(1)
except Exception as e:
    print(f'⚠️  Database check failed: {e}')
    sys.exit(1)
"

if [ $? -ne 0 ]; then
    echo ""
    read -p "Initialize database now? (y/N): " -n 1 -r
    echo
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        echo "🚀 Initializing database..."
        python3 initialize_hybrid_db.py
    fi
fi

echo ""
echo "=================================="
echo "🚀 Starting BioSemantica Server"
echo "=================================="
echo ""
echo "Backend: http://localhost:8000"
echo "Frontend: Open index.html in browser"
echo ""
echo "Press Ctrl+C to stop"
echo ""

python3 app_final.py
