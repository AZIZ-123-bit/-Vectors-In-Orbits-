# 🚀 QUICK START GUIDE - BioSemantica

## ⚡ Super Fast Setup (5 Minutes)

### Step 1: Install Dependencies (2 min)
```bash
pip install -r requirements_hybrid.txt
```

### Step 2: Initialize Database (2-3 min)
```bash
python initialize_hybrid_db.py
```
- Press 'yes' if asked to recreate collection
- Wait for embeddings to generate (~2-3 minutes)
- You'll see: "🎉 Initialization Complete!"

### Step 3: Start Backend (<1 min)
```bash
python app_final.py
```
- Should see: "🚀 Starting server on http://localhost:8000"
- Keep this terminal open!

### Step 4: Open Frontend
- Double-click `index.html` in your file browser
- Or open http://localhost:8000 in your browser

### Step 5: Start Searching! 🎉
Try these queries:
- "CRISPR gene editing"
- "protein folding mechanisms"
- "tumor suppressor genes"

---

## 🎯 For Your Hackathon Demo

### Best Demo Queries
1. **"CRISPR applications in cancer therapy"** - Shows semantic understanding
2. **"DNA sequencing methods"** - Shows content type filtering
3. **"protein expression 2024"** - Shows year filtering

### Demo Talking Points
✅ **3-stage hybrid search** (Dense + Sparse + ColBERT)
✅ **Sub-second response times** (~200-500ms)
✅ **Multi-modal support** (text, images, sequences)
✅ **Advanced filtering** (year, content type, metadata)
✅ **Production-ready** (Flask API + Cloud database)

### Troubleshooting During Demo

**Backend won't start?**
```bash
python --version  # Check it's 3.8+
pip install flask flask-cors qdrant-client fastembed chonkie
python app_final.py
```

**No search results?**
```bash
python initialize_hybrid_db.py
# Say 'yes' to recreate
```

**Connection error?**
- Make sure backend is running (green text in terminal)
- Refresh the browser page
- Check browser console (F12) for errors

---

## 📊 System Architecture (For Presentation)

```
┌─────────────┐
│  Frontend   │  Beautiful 3D UI with animations
│  (Browser)  │  Real-time search, filters, results
└──────┬──────┘
       │ AJAX/JSON
       ▼
┌─────────────┐
│  Flask API  │  RESTful endpoints
│  (Backend)  │  Request validation, routing
└──────┬──────┘
       │
       ▼
┌─────────────────────┐
│  Hybrid Search      │  3-stage search:
│  Engine             │  1. Dense (semantic)
│                     │  2. Sparse (keywords)
│                     │  3. ColBERT (rerank)
└──────┬──────────────┘
       │
       ▼
┌─────────────┐
│   Qdrant    │  Cloud vector database
│   Cloud     │  3 vector types, HNSW index
└─────────────┘
```

---

## 🏆 Why Our Solution Wins

1. **State-of-the-Art Tech**
   - Latest hybrid search architecture
   - Multiple embedding models
   - Production-ready implementation

2. **Real-World Application**
   - Solves actual research problem
   - Handles multiple data types
   - Scalable to millions of documents

3. **Beautiful UX**
   - Modern 3D interface
   - Responsive design
   - Smooth animations

4. **Complete Solution**
   - Full documentation
   - Easy setup
   - Ready for production

---

## 📞 Last-Minute Help

**5 minutes before demo and something breaks?**

1. **Quick reset:**
```bash
# Kill everything
pkill -f python

# Restart fresh
python app_final.py
```

2. **If database is corrupted:**
```bash
python initialize_hybrid_db.py
# Type: yes
```

3. **If frontend breaks:**
- Clear browser cache (Ctrl+Shift+Delete)
- Refresh (Ctrl+R)
- Check console (F12)

---

## 💪 You Got This!

Your project is:
✅ Technically advanced
✅ Visually impressive  
✅ Well documented
✅ Production-ready

**Good luck with your presentation! 🎉🚀**

---

*Team North Pole - Vector in Orbits Hackathon*
